"""Verifier configuration for a tool.

A tool needs to verify tokens and know where to send unauthenticated users. That
requires *no* WorkOS secret and *no* database URL — only public knowledge: the
issuer, the audience, and where to find the public keys (a JWKS URL, or an
inlined public key/JWKS for air-gapped or test setups). This is the whole point
of the asymmetric design in the Phase 1 spec: tools hold public verification
material only.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Mapping
from urllib.parse import urlsplit

from . import claims
from .errors import ConfigurationError


@dataclass
class AuthConfig:
    """Everything a tool needs to verify ``arb_session`` and redirect to login."""

    issuer: str
    login_url: str
    refresh_url: str | None = None
    audience: str = claims.DEFAULT_AUDIENCE
    cookie_name: str = claims.DEFAULT_COOKIE_NAME
    algorithms: tuple[str, ...] = (claims.DEFAULT_ALGORITHM,)
    leeway_seconds: int = 30

    # Exactly one key source is used, in this precedence: an inlined public key
    # (PEM), an inlined JWKS dict, or a JWKS URL to fetch and cache. Tests and
    # single-key deployments use the first; production tools use the URL.
    public_key: str | None = None
    jwks: dict | None = None
    jwks_url: str | None = None

    # Hosts a post-login ``return_to`` may point at (open-redirect guard on the
    # tool side). Empty means "same host only".
    allowed_return_hosts: tuple[str, ...] = field(default_factory=tuple)
    return_origin: str | None = None

    def __post_init__(self) -> None:
        if not self.issuer:
            raise ConfigurationError("AuthConfig requires an issuer")
        if not self.login_url:
            raise ConfigurationError("AuthConfig requires a login_url")
        if not (self.public_key or self.jwks or self.jwks_url):
            raise ConfigurationError(
                "AuthConfig requires a key source: public_key, jwks, or jwks_url"
            )
        if self.return_origin:
            parts = urlsplit(self.return_origin)
            if (
                parts.scheme not in ("http", "https")
                or not parts.hostname
                or parts.path not in ("", "/")
                or parts.query or parts.fragment or parts.username or parts.password
                or parts.hostname.lower() not in {host.lower() for host in self.allowed_return_hosts}
            ):
                raise ConfigurationError("ARBORETUM_RETURN_ORIGIN must be an allowed HTTP(S) origin")
            self.return_origin = self.return_origin.rstrip("/")

    @classmethod
    def from_env(cls, environ: Mapping[str, str] | None = None) -> "AuthConfig":
        """Build from ARBORETUM_* environment variables.

        The only required variable is ARBORETUM_ACCOUNTS_URL (the account
        service's base URL); issuer, login URL and JWKS URL are derived from it
        unless explicitly overridden. A tool can therefore be pointed at staging
        vs production by changing a single URL.
        """
        env = os.environ if environ is None else environ
        base = (env.get("ARBORETUM_ACCOUNTS_URL") or "").rstrip("/")

        issuer = env.get("ARBORETUM_ISSUER") or base
        login_url = env.get("ARBORETUM_LOGIN_URL") or (f"{base}/login" if base else "")
        refresh_url = env.get("ARBORETUM_REFRESH_URL") or (f"{base}/refresh" if base else None)

        public_key = env.get("ARBORETUM_PUBLIC_KEY")
        key_path = env.get("ARBORETUM_PUBLIC_KEY_PATH")
        if not public_key and key_path:
            with open(key_path, "r", encoding="utf-8") as handle:
                public_key = handle.read()

        jwks_url = env.get("ARBORETUM_JWKS_URL")
        if not jwks_url and not public_key and base:
            jwks_url = f"{base}/.well-known/jwks.json"

        allowed = env.get("ARBORETUM_ALLOWED_RETURN_HOSTS", "")
        allowed_hosts = tuple(h.strip() for h in allowed.split(",") if h.strip())

        if not base and not (public_key or jwks_url):
            raise ConfigurationError(
                "set ARBORETUM_ACCOUNTS_URL (or ARBORETUM_JWKS_URL / "
                "ARBORETUM_PUBLIC_KEY[_PATH]) so the verifier has a key source"
            )

        return cls(
            issuer=issuer,
            login_url=login_url,
            refresh_url=refresh_url,
            audience=env.get("ARBORETUM_AUDIENCE", claims.DEFAULT_AUDIENCE),
            cookie_name=env.get("ARBORETUM_COOKIE_NAME", claims.DEFAULT_COOKIE_NAME),
            leeway_seconds=int(env.get("ARBORETUM_JWT_LEEWAY", "30")),
            public_key=public_key,
            jwks_url=jwks_url,
            allowed_return_hosts=allowed_hosts,
            return_origin=env.get("ARBORETUM_RETURN_ORIGIN") or None,
        )
