"""The access-token wire format, in one place.

The account service mints the ``arb_session`` token and every tool verifies it.
If they disagreed about claim names the failure would be silent (a missing claim
reads as ``None``), so the schema lives in the reusable package that both sides
import. Nothing secret lives here — only names and public defaults.
"""

from __future__ import annotations

# Cross-subdomain access-token cookie. Set by the account service on the parent
# domain (e.g. ``.arboretuminvestments.net``) so every tool subdomain receives it.
DEFAULT_COOKIE_NAME = "arb_session"

# Fixed audience string tools require, so a token minted for the tools fleet is
# not accidentally accepted somewhere it was not intended.
DEFAULT_AUDIENCE = "arboretum-tools"

# Asymmetric signing: the account service holds the private key, tools verify
# with the public key (JWKS). RS256 is what WorkOS's own JWKS uses, so any future
# non-Python tool can verify with an off-the-shelf library.
DEFAULT_ALGORITHM = "RS256"

# Registered claims.
CLAIM_ISSUER = "iss"
CLAIM_SUBJECT = "sub"          # internal account id (stable, opaque)
CLAIM_AUDIENCE = "aud"
CLAIM_ISSUED_AT = "iat"
CLAIM_EXPIRES_AT = "exp"
CLAIM_JWT_ID = "jti"

# Arboretum private claims.
CLAIM_EMAIL = "email"          # normalized, WorkOS-verified email
CLAIM_PLAN = "plan"            # 'free' | 'premium' | 'max'
CLAIM_WORKOS_USER_ID = "wos_user_id"  # stable WorkOS user id (the account key)
CLAIM_SESSION_ID = "sid"       # account-service session id (revocation handle)
