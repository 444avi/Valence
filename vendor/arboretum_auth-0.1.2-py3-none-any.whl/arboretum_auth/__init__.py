"""arboretum_auth — the reusable customer-auth client for Arboretum tools.

A tool integrates auth by verifying the account service's ``arb_session`` token
with a public key and redirecting unauthenticated users to central login. It
does not talk to WorkOS and does not touch the accounts database.

Core (framework-free) API is exported here. Framework glue lives in
``arboretum_auth.flask_integration`` / ``arboretum_auth.fastapi_integration`` and
is imported explicitly so those web frameworks stay optional.
"""

from __future__ import annotations

from .claims import DEFAULT_ALGORITHM, DEFAULT_AUDIENCE, DEFAULT_COOKIE_NAME
from .config import AuthConfig
from .errors import (
    ArboretumAuthError,
    ConfigurationError,
    InvalidSession,
    VerificationUnavailable,
)
from .plans import TOOL_MIN_PLAN, Plan
from .redirects import build_login_url, safe_return_to
from .user import AuthenticatedUser
from .verifier import SessionVerifier

__version__ = "0.1.0"

__all__ = [
    "AuthConfig",
    "AuthenticatedUser",
    "SessionVerifier",
    "Plan",
    "TOOL_MIN_PLAN",
    "InvalidSession",
    "VerificationUnavailable",
    "ConfigurationError",
    "ArboretumAuthError",
    "safe_return_to",
    "build_login_url",
    "DEFAULT_COOKIE_NAME",
    "DEFAULT_AUDIENCE",
    "DEFAULT_ALGORITHM",
    "__version__",
]
