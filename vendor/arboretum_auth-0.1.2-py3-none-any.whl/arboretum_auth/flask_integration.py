"""Flask glue for tools (the Phase 2 Teasel integration target).

Usage in a tool::

    from arboretum_auth import AuthConfig
    from arboretum_auth.flask_integration import FlaskAuth

    auth = FlaskAuth(AuthConfig.from_env())

    @app.get("/")
    @auth.login_required()               # any verified account (Free+)
    def index():
        return render_template("index.html", user=auth.current_user())

    @app.post("/api/analyze")
    @auth.login_required(min_plan="premium")
    def analyze():
        ...

Flask is imported lazily so ``import arboretum_auth`` works in a FastAPI-only
tool (or in tests) without Flask installed.
"""

from __future__ import annotations

from functools import wraps
from typing import Callable

from .config import AuthConfig
from .errors import InvalidSession, VerificationUnavailable
from .plans import Plan
from .redirects import build_login_url, safe_return_to
from .user import AuthenticatedUser
from .verifier import SessionVerifier

_G_KEY = "_arboretum_user"


class FlaskAuth:
    def __init__(self, config: AuthConfig, verifier: SessionVerifier | None = None) -> None:
        self.config = config
        self.verifier = verifier or SessionVerifier(config)

    def current_user(self) -> AuthenticatedUser | None:
        """The verified user for this request, or None. Cached on ``g``."""
        from flask import g

        cached = g.__dict__.get(_G_KEY, _UNSET)
        if cached is not _UNSET:
            return cached
        user = self._verify_request()
        g.__dict__[_G_KEY] = user
        return user

    def login_required(self, min_plan: Plan | str = Plan.FREE, *, api: bool = False) -> Callable:
        """Require a session. API routes get JSON errors; pages get browser redirects."""
        required = Plan.coerce(min_plan)

        def decorator(view: Callable) -> Callable:
            @wraps(view)
            def wrapper(*args, **kwargs):
                from flask import g, jsonify, redirect, request

                token = request.cookies.get(self.config.cookie_name, "")
                try:
                    user = self.verifier.verify(token)
                except VerificationUnavailable:
                    # Transient: we could not check the token. Fail closed for
                    # this request but do not log the user out.
                    if api:
                        return jsonify(error="Session verification is temporarily unavailable."), 503
                    return "Session verification is temporarily unavailable. Please retry.", 503
                except InvalidSession:
                    auth_url = self._auth_redirect_for_request(api=api)
                    if api:
                        return jsonify(error="Authentication required.", auth_url=auth_url), 401
                    if request.args.get("_arb_auth_attempt") == "1":
                        # The account service already tried refresh/login and
                        # returned here without a usable cookie. Stop the loop.
                        return "Sign-in did not complete. Check your cookies and try again.", 401
                    return redirect(auth_url)
                if not user.has_plan(required):
                    if api:
                        return jsonify(error="Your account plan does not allow this request."), 403
                    return "Your account plan does not allow this page.", 403
                g.__dict__[_G_KEY] = user
                if not api and request.args.get("_arb_auth_attempt") == "1":
                    return redirect(self._return_target(request, api=False, retry=False))
                return view(*args, **kwargs)

            return wrapper

        return decorator

    def login_redirect(self, return_to: str | None) -> str:
        """The account-service login URL, carrying a validated return target."""
        target = safe_return_to(
            return_to,
            allowed_hosts=self.config.allowed_return_hosts,
            default="/",
        )
        return build_login_url(self.config.login_url, target)

    def _auth_redirect_for_request(self, *, api: bool) -> str:
        from flask import request

        target = self._return_target(request, api=api, retry=True)
        return build_login_url(self.config.refresh_url or self.config.login_url, target)

    def _return_target(self, request, *, api: bool, retry: bool) -> str:
        from urllib.parse import urlencode

        # A browser cannot GET a POST-only API after the account-service hop.
        # Send API callers to the tool home; page requests preserve deep links.
        path = "/" if api else request.path
        params = [] if api else [(k, v) for k, v in request.args.items(multi=True) if k != "_arb_auth_attempt"]
        if retry:
            params.append(("_arb_auth_attempt", "1"))
        query = urlencode(params)
        origin = self.config.return_origin
        if origin is None:
            candidate = request.url_root.rstrip("/")
            origin = safe_return_to(candidate + "/", allowed_hosts=self.config.allowed_return_hosts, default="").rstrip("/")
        target = f"{origin}{path}{'?' + query if query else ''}" if origin else "/"
        return safe_return_to(target, allowed_hosts=self.config.allowed_return_hosts, default="/")

    def _verify_request(self) -> AuthenticatedUser | None:
        from flask import request

        token = request.cookies.get(self.config.cookie_name, "")
        try:
            return self.verifier.verify(token)
        except (InvalidSession, VerificationUnavailable):
            return None


class _Unset:
    __slots__ = ()


_UNSET = _Unset()
