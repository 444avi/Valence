"""FastAPI glue for tools (e.g. a future Valence integration).

The same verifier, exposed as a dependency::

    from arboretum_auth import AuthConfig
    from arboretum_auth.fastapi_integration import FastAPIAuth

    auth = FastAPIAuth(AuthConfig.from_env())

    @app.get("/runs")
    def list_runs(user = Depends(auth.require_user(min_plan="max"))):
        ...

FastAPI is imported lazily. Tools that serve JSON get a 401 (with a ``Location``
header pointing at login) rather than a 302, since redirecting an XHR is rarely
what an API client wants; a page-serving route can read that header to redirect.
"""

from __future__ import annotations

from typing import Callable

from .config import AuthConfig
from .errors import InvalidSession, VerificationUnavailable
from .plans import Plan
from .redirects import build_login_url, safe_return_to
from .user import AuthenticatedUser
from .verifier import SessionVerifier


class FastAPIAuth:
    def __init__(self, config: AuthConfig, verifier: SessionVerifier | None = None) -> None:
        self.config = config
        self.verifier = verifier or SessionVerifier(config)

    def require_user(self, min_plan: Plan | str = Plan.FREE) -> Callable:
        """Build a dependency that yields an AuthenticatedUser or raises HTTP 401/403/503."""
        from fastapi import HTTPException, Request

        required = Plan.coerce(min_plan)

        def dependency(request: Request) -> AuthenticatedUser:
            token = request.cookies.get(self.config.cookie_name, "")
            try:
                user = self.verifier.verify(token)
            except VerificationUnavailable:
                raise HTTPException(status_code=503, detail="auth temporarily unavailable")
            except InvalidSession:
                # The request's own host is a safe return target (same-origin).
                allowed = tuple(self.config.allowed_return_hosts) + (
                    (request.url.hostname,) if request.url.hostname else ()
                )
                target = safe_return_to(str(request.url), allowed_hosts=allowed, default="/")
                raise HTTPException(
                    status_code=401,
                    detail="authentication required",
                    headers={"Location": build_login_url(self.config.login_url, target)},
                )
            if not user.has_plan(required):
                raise HTTPException(status_code=403, detail="plan upgrade required")
            return user

        return dependency

    def login_redirect(self, return_to: str | None) -> str:
        target = safe_return_to(
            return_to,
            allowed_hosts=self.config.allowed_return_hosts,
            default="/",
        )
        return build_login_url(self.config.login_url, target)
