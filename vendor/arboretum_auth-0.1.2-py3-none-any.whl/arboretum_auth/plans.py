"""Entitlement tiers shared by the account service and every tool.

Phase 1 needs exactly one thing from entitlements: an ordering where
``free < premium < max`` so a tool can ask "is this user at least premium?"
without knowing anything about billing. Max is a superset of Premium which is a
superset of Free, so the check is a single rank comparison.

There is intentionally no plan-changing logic here — plans only move when the
(future) Stripe integration writes the account row. This module is the one place
that defines what the tiers are and how they compare.
"""

from __future__ import annotations

from enum import Enum


class Plan(Enum):
    """A customer's entitlement tier. Values are the on-the-wire/stored strings."""

    FREE = "free"
    PREMIUM = "premium"
    MAX = "max"

    @property
    def rank(self) -> int:
        return _RANK[self]

    def satisfies(self, required: "Plan") -> bool:
        """True when holding this plan grants access to something needing ``required``."""
        return self.rank >= required.rank

    @classmethod
    def coerce(cls, value: "Plan | str") -> "Plan":
        """Parse a stored/claim string (or pass a Plan through). Raises ValueError."""
        if isinstance(value, Plan):
            return value
        try:
            return cls(str(value).strip().lower())
        except ValueError as exc:  # normalize the message for callers/logs
            raise ValueError(f"unknown plan: {value!r}") from exc

    # Ordering is defined explicitly (rather than via functools.total_ordering)
    # so comparisons against non-Plan values return NotImplemented cleanly and
    # Enum's identity-based __eq__/__hash__ are left untouched.
    def __lt__(self, other: object) -> bool:
        if not isinstance(other, Plan):
            return NotImplemented
        return self.rank < other.rank

    def __le__(self, other: object) -> bool:
        if not isinstance(other, Plan):
            return NotImplemented
        return self.rank <= other.rank

    def __gt__(self, other: object) -> bool:
        if not isinstance(other, Plan):
            return NotImplemented
        return self.rank > other.rank

    def __ge__(self, other: object) -> bool:
        if not isinstance(other, Plan):
            return NotImplemented
        return self.rank >= other.rank


_RANK: dict[Plan, int] = {Plan.FREE: 0, Plan.PREMIUM: 1, Plan.MAX: 2}

# The five Arboretum tools mapped to the minimum plan that unlocks them. This is
# a convenience/reference table for integrators (and the account page); each tool
# still enforces its own requirement via ``login_required(min_plan=...)``.
TOOL_MIN_PLAN: dict[str, Plan] = {
    "teasel": Plan.FREE,       # free, but requires a verified account
    "overstory": Plan.PREMIUM,
    "avalpha": Plan.PREMIUM,
    "sundew": Plan.PREMIUM,
    "valence": Plan.MAX,
}
