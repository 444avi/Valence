"""Framework-agnostic verification of the ``arb_session`` access token.

This is the heart of the reusable package. Given a token string it returns an
``AuthenticatedUser`` or raises — ``InvalidSession`` for a bad token,
``VerificationUnavailable`` when the public keys could not be fetched. It uses
only public key material, so a tool embedding this needs no WorkOS or database
secret.

Key resolution precedence mirrors AuthConfig: an inlined public key, an inlined
JWKS, then a JWKS URL fetched and cached via PyJWT's ``PyJWKClient``.
"""

from __future__ import annotations

from typing import Mapping

import jwt
from jwt import PyJWKClient
from jwt.exceptions import (
    ExpiredSignatureError,
    InvalidTokenError,
    PyJWKClientError,
)

try:  # PyJWT >= 2.8 distinguishes a fetch/transport failure from "no such key".
    from jwt.exceptions import PyJWKClientConnectionError
except ImportError:  # pragma: no cover - older PyJWT
    PyJWKClientConnectionError = None  # type: ignore[assignment]

from .config import AuthConfig
from .errors import ExpiredSession, InvalidSession, VerificationUnavailable
from .user import AuthenticatedUser


class SessionVerifier:
    """Verifies access tokens against a configured issuer/audience and key source."""

    def __init__(self, config: AuthConfig) -> None:
        self._config = config
        self._jwk_client: PyJWKClient | None = None
        self._jwk_by_kid: dict[str | None, "jwt.PyJWK"] | None = None

        if config.public_key:
            # Single static key: kid in the token header is ignored.
            self._static_key = config.public_key
        else:
            self._static_key = None
            if config.jwks:
                key_set = jwt.PyJWKSet.from_dict(config.jwks)
                self._jwk_by_kid = {k.key_id: k for k in key_set.keys}
            elif config.jwks_url:
                # PyJWKClient fetches lazily and caches by kid across calls.
                # A named client also lets edge security distinguish this
                # legitimate JWKS fetch from Python's generic urllib agent.
                self._jwk_client = PyJWKClient(
                    config.jwks_url,
                    cache_keys=True,
                    headers={"User-Agent": "ArboretumAuth/0.1.2"},
                )

    @property
    def config(self) -> AuthConfig:
        return self._config

    def verify(self, token: str) -> AuthenticatedUser:
        """Verify a token string, returning the user or raising.

        Raises:
            InvalidSession: token missing/malformed/expired/failing claim checks.
            VerificationUnavailable: signing keys could not be fetched.
        """
        if not token:
            raise InvalidSession("no token presented")

        key = self._resolve_key(token)
        try:
            payload = jwt.decode(
                token,
                key,
                algorithms=list(self._config.algorithms),
                audience=self._config.audience,
                issuer=self._config.issuer,
                leeway=self._config.leeway_seconds,
                options={"require": ["exp", "iat", "iss", "aud", "sub"]},
            )
        except ExpiredSignatureError as exc:
            raise ExpiredSession("token expired") from exc
        except InvalidTokenError as exc:
            # Covers bad signature, wrong aud/iss, missing required claims, etc.
            raise InvalidSession(f"invalid token: {exc}") from exc

        try:
            return AuthenticatedUser.from_claims(payload)
        except (KeyError, ValueError) as exc:
            raise InvalidSession(f"unusable claims: {exc}") from exc

    def verify_cookies(self, cookies: Mapping[str, str]) -> AuthenticatedUser:
        """Convenience: pull the configured cookie out of a cookie mapping."""
        return self.verify(cookies.get(self._config.cookie_name, ""))

    # ---- key resolution --------------------------------------------------

    def _resolve_key(self, token: str):
        if self._static_key is not None:
            return self._static_key

        try:
            header = jwt.get_unverified_header(token)
        except InvalidTokenError as exc:
            raise InvalidSession(f"unreadable token header: {exc}") from exc
        kid = header.get("kid")

        if self._jwk_by_kid is not None:
            key = self._jwk_by_kid.get(kid)
            if key is None:
                raise InvalidSession(f"unknown key id: {kid!r}")
            return key.key

        if self._jwk_client is not None:
            try:
                return self._jwk_client.get_signing_key_from_jwt(token).key
            except Exception as exc:  # narrow below
                raise self._classify_jwks_error(exc)

        # Should be unreachable: AuthConfig guarantees a key source exists.
        raise VerificationUnavailable("no key source configured")

    @staticmethod
    def _classify_jwks_error(exc: Exception) -> Exception:
        """A JWKS fetch failure is transient; a genuine 'no matching key' is not."""
        if PyJWKClientConnectionError is not None and isinstance(
            exc, PyJWKClientConnectionError
        ):
            return VerificationUnavailable(f"could not fetch JWKS: {exc}")
        if isinstance(exc, PyJWKClientError):
            msg = str(exc).lower()
            # Heuristic for PyJWT builds without the connection-error subclass.
            if "fetch" in msg or "connection" in msg or "timed out" in msg:
                return VerificationUnavailable(f"could not fetch JWKS: {exc}")
            return InvalidSession(f"no matching signing key: {exc}")
        return VerificationUnavailable(f"key resolution failed: {exc}")
