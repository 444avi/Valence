"""The stable authenticated-user representation every tool receives.

This is the *only* identity object tools should pass around. It is deliberately
small and framework-free: an id, the verified email, the plan, and the token's
validity window. Tools never see WorkOS tokens, database rows, or cookies — just
this. Keeping the shape here (rather than each tool inventing its own dict) is
what lets the reusable package be a real contract.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Mapping

from . import claims
from .plans import Plan


@dataclass(frozen=True)
class AuthenticatedUser:
    """A verified customer, decoded from a valid ``arb_session`` token."""

    id: str                    # internal account id (token 'sub')
    workos_user_id: str        # stable WorkOS id (the account key)
    email: str                 # normalized, verified
    plan: Plan
    session_id: str | None     # account-service session id, if present
    issued_at: datetime
    expires_at: datetime

    def has_plan(self, required: Plan | str) -> bool:
        """True when this user's plan is at least ``required`` (free<premium<max)."""
        return self.plan.satisfies(Plan.coerce(required))

    @classmethod
    def from_claims(cls, payload: Mapping[str, Any]) -> "AuthenticatedUser":
        """Build from decoded JWT claims. Raises ValueError/KeyError if malformed;
        the verifier converts those into InvalidSession."""
        return cls(
            id=str(payload[claims.CLAIM_SUBJECT]),
            workos_user_id=str(payload[claims.CLAIM_WORKOS_USER_ID]),
            email=str(payload[claims.CLAIM_EMAIL]),
            plan=Plan.coerce(payload[claims.CLAIM_PLAN]),
            session_id=(
                str(payload[claims.CLAIM_SESSION_ID])
                if payload.get(claims.CLAIM_SESSION_ID) is not None
                else None
            ),
            issued_at=_epoch_to_dt(payload[claims.CLAIM_ISSUED_AT]),
            expires_at=_epoch_to_dt(payload[claims.CLAIM_EXPIRES_AT]),
        )


def _epoch_to_dt(value: Any) -> datetime:
    return datetime.fromtimestamp(int(value), tz=timezone.utc)
