"""Open-redirect-safe handling of ``return_to`` targets.

Both the tool (when sending a user to log in) and the account service (when
sending them back afterwards) must refuse to bounce a browser to an attacker's
URL. The rule is: allow same-origin relative paths, and allow absolute URLs only
to an explicit host allowlist. Anything else collapses to a safe default. This is
shared so the tool and the service apply identical logic.
"""

from __future__ import annotations

from urllib.parse import quote, urlsplit, urlunsplit


def safe_return_to(
    target: str | None,
    *,
    allowed_hosts: tuple[str, ...] | list[str] = (),
    default: str = "/",
) -> str:
    """Return ``target`` if it is a safe redirect destination, else ``default``.

    Safe means: a relative path beginning with a single ``/`` (not ``//`` or
    ``/\\``, which browsers treat as protocol-relative), or an http(s) absolute
    URL whose host is in ``allowed_hosts``.
    """
    if not target:
        return default

    # Reject anything with control characters/newlines outright.
    if any(ord(c) < 0x20 or ord(c) == 0x7F for c in target) or "\\" in target:
        return default

    try:
        parts = urlsplit(target)
    except ValueError:
        return default

    if parts.scheme or parts.netloc:
        if parts.scheme not in ("http", "https"):
            return default
        try:
            host = (parts.hostname or "").lower()
        except ValueError:
            return default
        if host and host in {h.lower() for h in allowed_hosts} and not (parts.username or parts.password):
            # Drop any fragment; keep path+query.
            return urlunsplit((parts.scheme, parts.netloc, parts.path or "/", parts.query, ""))
        return default

    # Relative reference: must be host-absolute and not protocol-relative.
    if not target.startswith("/") or target.startswith("//") or target.startswith("/\\"):
        return default
    return target


def build_login_url(login_url: str, return_to: str | None) -> str:
    """Compose ``{login_url}?return_to=...`` with the target percent-encoded."""
    if not return_to:
        return login_url
    sep = "&" if "?" in login_url else "?"
    return f"{login_url}{sep}return_to={quote(return_to, safe='')}"
