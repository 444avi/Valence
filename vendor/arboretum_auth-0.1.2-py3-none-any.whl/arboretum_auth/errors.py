"""Errors raised by the verifier.

The important distinction, repeated throughout Arboretum auth, is *invalid* vs
*unavailable*. An invalid session is a real answer ("this token is not good, send
the user to log in"); an unavailable verifier is a transient infrastructure fault
("we could not fetch the public keys right now, do not conclude anything"). Tools
must treat them differently: 302 to login for the first, 503/retry for the second.
"""

from __future__ import annotations


class ArboretumAuthError(Exception):
    """Base class for everything this package raises."""


class ConfigurationError(ArboretumAuthError):
    """The verifier was constructed without a usable key source or issuer."""


class InvalidSession(ArboretumAuthError):
    """The token is missing, malformed, expired, or fails signature/claim checks.

    This is a definitive negative: the caller should treat the request as
    unauthenticated and redirect to login.
    """


class ExpiredSession(InvalidSession):
    """A correctly structured session whose access-token lifetime ended."""


class VerificationUnavailable(ArboretumAuthError):
    """The token could not be checked because key material was unreachable.

    This is *not* a statement about the token's validity. The caller should fail
    closed for this request (deny access) but must not destroy the session or
    treat the user as logged out — it should retry.
    """
